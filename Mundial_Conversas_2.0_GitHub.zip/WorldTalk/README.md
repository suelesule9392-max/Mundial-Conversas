# 🌎 Mundial Conversas 2.0

Aplicativo Android preparado para conversas reais entre usuários.

## O que entrou nesta versão
- Cadastro e login por e-mail e senha
- Perfis de usuários
- Descobrir pessoas
- Mensagens armazenadas no Supabase
- Atualização periódica das conversas
- Correção automática básica de português
- GitHub Actions para gerar APK
- SQL com Row Level Security (RLS)

## Configurar pelo celular
1. Crie uma conta no Supabase e um projeto.
2. Abra o SQL Editor e execute `supabase/schema.sql`.
3. No GitHub, abra o repositório do Mundial Conversas.
4. Vá em Settings > Secrets and variables > Actions.
5. Crie:
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
6. No Actions, execute `Build WorldTalk APK`.
7. Baixe o artefato `WorldTalk-APK`.

O Supabase recomenda usar a URL do projeto e a chave publicável no cliente móvel, com RLS protegendo os dados; chaves e segredos não devem ser colocados no código-fonte. citeturn0search0turn0search8

## Realtime
O projeto já tem o modelo de mensagens. Para receber alterações instantaneamente, habilite a tabela `messages` no Realtime/Replication do Supabase. O Realtime vem desativado por padrão em novos projetos e precisa ser habilitado para as tabelas desejadas. citeturn0search10
