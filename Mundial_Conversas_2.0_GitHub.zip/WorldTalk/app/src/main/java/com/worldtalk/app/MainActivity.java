package com.worldtalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import org.json.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(2,14,25), panel=Color.rgb(7,28,45), blue=Color.rgb(21,151,255), text=Color.WHITE, muted=Color.rgb(165,190,210);
    LinearLayout root, messages; EditText input; SupabaseClient api; String currentUser, otherUser, otherName;
    ExecutorService exec=Executors.newSingleThreadExecutor();
    Handler handler=new Handler(Looper.getMainLooper());

    public void onCreate(Bundle b){super.onCreate(b); api=new SupabaseClient(BuildConfig.SUPABASE_URL,BuildConfig.SUPABASE_KEY); if(api.configured()) login(); else welcome();}

    TextView tv(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setPadding(14,8,14,8);return v;}
    GradientDrawable box(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(box(blue,28));return b;}

    void welcome(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(28,20,28,20);root.setBackgroundColor(bg);setContentView(root);
        TextView a=tv("🌎",60,text);a.setGravity(17);root.addView(a);
        TextView t=tv("Mundial Conversas",30,text);t.setGravity(17);root.addView(t);
        TextView s=tv("Converse com pessoas do mundo inteiro\\n\\nA versão online precisa das configurações do servidor.",16,muted);s.setGravity(17);root.addView(s);
        Button b=btn("Como conectar");root.addView(b,new LinearLayout.LayoutParams(-1,60));b.setOnClickListener(v->Toast.makeText(this,"Configure SUPABASE_URL e SUPABASE_PUBLISHABLE_KEY no GitHub.",Toast.LENGTH_LONG).show());
    }
    void login(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,35,22,20);root.setBackgroundColor(bg);setContentView(root);
        TextView t=tv("🌎 Mundial Conversas",28,text);t.setGravity(17);root.addView(t);
        EditText e=new EditText(this);e.setHint("Seu e-mail");e.setTextColor(text);e.setHintTextColor(muted);root.addView(e,new LinearLayout.LayoutParams(-1,60));
        EditText p=new EditText(this);p.setHint("Senha");p.setInputType(129);p.setTextColor(text);p.setHintTextColor(muted);root.addView(p,new LinearLayout.LayoutParams(-1,60));
        Button in=btn("Entrar");root.addView(in,new LinearLayout.LayoutParams(-1,60));
        Button up=btn("Criar conta");root.addView(up,new LinearLayout.LayoutParams(-1,60));
        in.setOnClickListener(v->auth(e.getText().toString(),p.getText().toString(),false));
        up.setOnClickListener(v->auth(e.getText().toString(),p.getText().toString(),true));
    }
    void auth(String e,String p,boolean signup){if(e.isEmpty()||p.length()<6){Toast.makeText(this,"Informe e-mail e senha com 6+ caracteres.",Toast.LENGTH_SHORT).show();return;}
        exec.submit(()->{try{if(signup)api.signUp(e,p); api.signIn(e,p); currentUser=api.userId(); runOnUiThread(()->discover());}catch(Exception x){runOnUiThread(()->Toast.makeText(this,"Erro: "+x.getMessage(),Toast.LENGTH_LONG).show());}});
    }
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(10,8,10,6);root.setBackgroundColor(bg);setContentView(root);
        TextView t=tv("🌎 "+title,22,text);t.setTypeface(null,1);root.addView(t,new LinearLayout.LayoutParams(-1,55));
        LinearLayout nav=new LinearLayout(this);String[] n={"Conversas","Descobrir","Perfil"};for(String x:n){TextView v=tv(x,13,muted);v.setGravity(17);nav.addView(v,new LinearLayout.LayoutParams(0,42,1));v.setOnClickListener(q->{if(x.equals("Descobrir"))discover();else if(x.equals("Perfil"))profile();else if(otherUser!=null)chat(otherUser,otherName);});}root.addView(nav);
    }
    void discover(){base("Descobrir");ScrollView sc=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        exec.submit(()->{try{JSONArray a=api.profiles();runOnUiThread(()->{try{for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.getString("id").equals(currentUser))continue;LinearLayout r=new LinearLayout(this);TextView v=tv(o.getString("display_name")+"\\n"+o.optString("country")+" • "+o.optString("language"),16,text);r.addView(v,new LinearLayout.LayoutParams(0,75,1));Button b=btn("Conversar");r.addView(b,new LinearLayout.LayoutParams(105,55));String id=o.getString("id"),name=o.getString("display_name");b.setOnClickListener(x->chat(id,name));list.addView(r);}}catch(Exception e){}});}catch(Exception x){runOnUiThread(()->Toast.makeText(this,"Não foi possível carregar pessoas.",Toast.LENGTH_SHORT).show());}});
    }
    void chat(String id,String name){otherUser=id;otherName=name;base(name);messages=new LinearLayout(this);messages.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(messages);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        input=new EditText(this);input.setHint("Digite uma mensagem...");input.setTextColor(text);input.setHintTextColor(muted);input.setBackground(box(panel,25));Button corr=btn("✓ Corrigir"),send=btn("➤");LinearLayout bar=new LinearLayout(this);bar.addView(input,new LinearLayout.LayoutParams(0,60,1));bar.addView(corr,new LinearLayout.LayoutParams(90,60));bar.addView(send,new LinearLayout.LayoutParams(72,60));root.addView(bar);corr.setOnClickListener(v->{input.setText(fix(input.getText().toString()));input.setSelection(input.length());});send.setOnClickListener(v->send());load();handler.postDelayed(new Runnable(){public void run(){if(otherUser!=null){load();handler.postDelayed(this,2500);}}},2500);}
    String fix(String x){x=x.trim();String[] p={"vc","você","tbm","também","q","que","pq","porque","nao","não","ola","olá","voce","você"};for(int i=0;i<p.length;i+=2)x=x.replaceAll("(?i)\\\\b"+p[i]+"\\\\b",p[i+1]);if(!x.isEmpty())x=Character.toUpperCase(x.charAt(0))+x.substring(1);return x;}
    void load(){if(otherUser==null)return;exec.submit(()->{try{JSONArray a=api.messages(otherUser);runOnUiThread(()->{messages.removeAllViews();try{for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);boolean me=o.getString("sender_id").equals(currentUser);TextView m=tv(o.getString("body"),15,text);m.setBackground(box(me?blue:panel,22));m.setGravity(me?Gravity.RIGHT:Gravity.LEFT);m.setPadding(16,12,16,12);messages.addView(m,new LinearLayout.LayoutParams(-1,55));}}catch(Exception e){}});}catch(Exception ignored){}});}
    void send(){String s=fix(input.getText().toString());if(s.isEmpty())return;exec.submit(()->{try{api.send(otherUser,s);runOnUiThread(()->input.setText(""));}catch(Exception x){runOnUiThread(()->Toast.makeText(this,"Falha ao enviar.",Toast.LENGTH_SHORT).show());}});}
    void profile(){base("Meu perfil");TextView t=tv("🌎\\n\\nMundial Conversas\\n\\nCorreção automática ✓\\nMensagens online ✓\\nTradução automática (próxima etapa)",20,text);t.setGravity(17);root.addView(t,new LinearLayout.LayoutParams(-1,0,1));}
}
