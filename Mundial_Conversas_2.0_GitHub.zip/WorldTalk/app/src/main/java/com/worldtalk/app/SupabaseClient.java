package com.worldtalk.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class SupabaseClient {
    private String url, key, accessToken;
    public SupabaseClient(String url, String key) { this.url=url; this.key=key; }

    private String request(String method, String endpoint, String body, boolean auth) throws Exception {
        URL u = new URL(url + endpoint);
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod(method);
        c.setRequestProperty("apikey", key);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Prefer", "return=representation");
        if (auth && accessToken != null) c.setRequestProperty("Authorization", "Bearer " + accessToken);
        if (body != null) {
            c.setDoOutput(true);
            try(OutputStream os=c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
        }
        int code=c.getResponseCode();
        InputStream is=code>=400?c.getErrorStream():c.getInputStream();
        StringBuilder out=new StringBuilder();
        if(is!=null) try(BufferedReader r=new BufferedReader(new InputStreamReader(is))) {
            String line; while((line=r.readLine())!=null) out.append(line);
        }
        if(code>=400) throw new Exception(out.toString());
        return out.toString();
    }

    public JSONObject signUp(String email, String password) throws Exception {
        JSONObject b=new JSONObject(); b.put("email",email); b.put("password",password);
        String r=request("POST","/auth/v1/signup",b.toString(),false);
        return new JSONObject(r);
    }
    public JSONObject signIn(String email, String password) throws Exception {
        JSONObject b=new JSONObject(); b.put("email",email); b.put("password",password);
        String r=request("POST","/auth/v1/token?grant_type=password",b.toString(),false);
        JSONObject o=new JSONObject(r); accessToken=o.optString("access_token"); return o;
    }
    public String userId() throws Exception {
        String[] p=accessToken.split("\\.");
        String json=new String(android.util.Base64.decode(p[1], android.util.Base64.URL_SAFE|android.util.Base64.NO_WRAP), StandardCharsets.UTF_8);
        return new JSONObject(json).getString("sub");
    }
    public void createProfile(String id,String username,String name,String country,String language) throws Exception {
        JSONObject b=new JSONObject(); b.put("id",id); b.put("username",username); b.put("display_name",name); b.put("country",country); b.put("language",language);
        request("POST","/rest/v1/profiles",b.toString(),true);
    }
    public JSONArray profiles() throws Exception {
        return new JSONArray(request("GET","/rest/v1/profiles?select=id,username,display_name,country,language&limit=50",null,true));
    }
    public JSONArray messages(String otherId) throws Exception {
        String uid=userId();
        String filter="or=(and(sender_id.eq."+uid+",receiver_id.eq."+otherId+"),and(sender_id.eq."+otherId+",receiver_id.eq."+uid+"))";
        return new JSONArray(request("GET","/rest/v1/messages?select=id,sender_id,receiver_id,body,created_at&"+URLEncoder.encode(filter,"UTF-8")+"&order=created_at.asc",null,true));
    }
    public void send(String receiverId,String body) throws Exception {
        JSONObject b=new JSONObject(); b.put("sender_id",userId()); b.put("receiver_id",receiverId); b.put("body",body);
        request("POST","/rest/v1/messages",b.toString(),true);
    }
    public boolean configured() {
        return !url.contains("SEU-PROJETO") && !key.contains("SUA_CHAVE");
    }
}
